<?php


$test = '$2a$08$Cf1213eParGlBJoOM0F6a.82GtLij71C3ZYUZKaT5Sc3CUUvlDlBq';


echo htmlspecialchars('$2a$08$Cf1213eParGlBJoOM0F6a.82GtLij71C3ZYUZKaT5Sc3CUUvlDlBq');


?>
