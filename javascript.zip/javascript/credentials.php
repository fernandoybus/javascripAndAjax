<?php


$server = "localhost";
$username = "lamp";
$password = "1";
$database = "javascript";


?>